#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/sensor.h>
#include <zephyr/sys/printk.h>
#include <zephyr/timing/timing.h>

#define STACKSIZE 2048
#define PRIORITY 5

const struct device *dht = DEVICE_DT_GET_ANY(aosong_dht);

K_THREAD_STACK_DEFINE(cpu_stack, STACKSIZE);
struct k_thread cpu_thread;

volatile uint64_t operation_time_us = 0;

void cpu_stress(void *a, void *b, void *c)
{
    volatile uint32_t x = 0;

    while (1) {
        for (int i = 0; i < 100000; i++) {
            x += i;
        }

        k_yield();
    }
}

void benchmark_task()
{
    struct sensor_value temp, hum;

    uint64_t start;
    uint64_t end;

    while (1) {

        start = timing_counter_get();

        if (sensor_sample_fetch(dht) == 0) {

            sensor_channel_get(
                dht,
                SENSOR_CHAN_AMBIENT_TEMP,
                &temp
            );

            sensor_channel_get(
                dht,
                SENSOR_CHAN_HUMIDITY,
                &hum
            );

            printk(
                "[DATA_OUTPUT] TEMP=%d.%06dC HUM=%d.%06d%%\n",
                temp.val1,
                temp.val2,
                hum.val1,
                hum.val2
            );
        } else {
            printk("[DATA_OUTPUT] SENSOR_READ_FAILED\n");
        }

        end = timing_counter_get();

        operation_time_us =
            timing_cycles_to_ns(end - start) / 1000;

        printk(
            "[DATA_OUTPUT] OPERATION_TIME_US=%llu\n",
            operation_time_us
        );

        printk(
            "[DATA_OUTPUT] FREE_HEAP_BYTES=%u\n",
            k_heap_avail_get(&_system_heap)
        );

        k_sleep(K_SECONDS(2));
    }
}

int main(void)
{
    timing_init();
    timing_start();

    if (!device_is_ready(dht)) {
        printk("[DATA_OUTPUT] DHT22_NOT_READY\n");
        return 0;
    }

    k_thread_create(
        &cpu_thread,
        cpu_stack,
        STACKSIZE,
        cpu_stress,
        NULL,
        NULL,
        NULL,
        PRIORITY,
        0,
        K_NO_WAIT
    );

    benchmark_task();

    return 0;
}