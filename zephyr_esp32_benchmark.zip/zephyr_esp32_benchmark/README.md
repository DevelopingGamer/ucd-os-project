# ESP32 Zephyr RTOS Benchmark

Hardware:
- ESP32 DevKit V1
- DHT22 Sensor

Connections:
DHT22 VCC -> 3.3V
DHT22 GND -> GND
DHT22 DATA -> GPIO4

Add 10k pull-up resistor between DATA and 3.3V.

Build:
west build -b esp32 .

Flash:
west flash

Serial Monitor:
west espressif monitor

This project only outputs real runtime measurements gathered from hardware.
No synthetic or generated benchmark values are used.